/*
 * Authors:
 *   1. <your name and student number>
 */
package comp3011;

/** Diagnostic: prints the average time a pipeline stage spends per frame, every 30 frames. One thread only. */
final class StageTimer {
    private final String name;
    private long totalNs;
    private int count;

    StageTimer(String name) {
        this.name = name;
    }

    void record(long elapsedNs) {
        totalNs += elapsedNs;
        if (++count == 30) {
            System.out.printf("%-26s %6.1f ms/frame%n", name, totalNs / 30 / 1_000_000.0);
            totalNs = 0;
            count = 0;
        }
    }
}